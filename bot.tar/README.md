# 🎯 Deep Diagnostic Bot

AI-powered Telegram бот для глубинной диагностики специалистов (дизайнеров и продактов) за 10 адаптивных вопросов.

## Что делает

- Оценивает уровень специалиста по шкале 0-100
- Анализирует 4 категории: Hard Skills, Soft Skills, Thinking, Mindset
- Каждый вопрос адаптируется под предыдущие ответы
- Генерирует детальный отчёт с сильными сторонами и зонами роста

## Быстрый старт

### 1. Клонирование и установка

```bash
cd TG-BOT
python -m venv venv
venv\Scripts\activate  # Windows
pip install -r requirements.txt
```

### 2. Настройка окружения

Скопируй `env-example.txt` → `.env` и заполни:

```env
BOT_TOKEN=7123456789:AAHdqTcvCH8k...   # от @BotFather
ROUTERAI_API_KEY=sk-...                 # от routerai.ru
AI_MODEL=anthropic/claude-sonnet-4.5    # или другая модель
```

### 3. Запуск

```bash
python -m src.bot.main
```

## Структура проекта

```
src/
├── bot/           # Telegram бот (aiogram)
│   ├── handlers/  # Обработчики команд
│   ├── keyboards/ # Inline клавиатуры
│   └── middlewares/
├── core/          # Конфигурация и промпты
│   └── prompts/   # Системные промпты для AI
├── ai/            # Интеграция с OpenAI/Claude
├── db/            # База данных (SQLAlchemy)
└── utils/         # Вспомогательные функции
```

## Технологии

- Python 3.11+
- aiogram 3.x — Telegram Bot API
- [RouterAI](https://routerai.ru/) — единый API для GPT-4, Claude, Gemini (оплата в рублях, без VPN)
- PostgreSQL — хранение результатов
- Redis — сессии

## Лицензия

MIT

