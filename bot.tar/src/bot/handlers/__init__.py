"""Обработчики команд бота."""
from src.bot.handlers import start, diagnostic, history, voice

__all__ = ["start", "diagnostic", "history", "voice"]
