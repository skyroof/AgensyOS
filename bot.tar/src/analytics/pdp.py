"""
Personal Development Plan (PDP) — мощный персональный план развития.

Включает:
- Приоритизированные зоны развития
- Конкретные шаги на 30/60/90 дней
- Рекомендуемые ресурсы (книги, курсы, практики, инструменты)
- Метрики успеха для отслеживания прогресса
- Персонализация по роли и уровню опыта
"""
from dataclasses import dataclass, field
from typing import Optional

from src.ai.answer_analyzer import ALL_METRICS, METRIC_NAMES_RU


# ========================================
# БАЗА РЕСУРСОВ ДЛЯ РАЗВИТИЯ
# ========================================

@dataclass
class Resource:
    """Ресурс для развития."""
    type: str  # book / course / practice / tool / article / community
    title: str
    author: str = ""
    url: str = ""
    description: str = ""
    duration: str = ""  # "2 часа" / "4 недели" / "ежедневно"
    difficulty: str = "medium"  # easy / medium / hard
    language: str = "ru"  # ru / en
    free: bool = False
    priority: int = 1  # 1 = высший


@dataclass
class DevelopmentAction:
    """Конкретное действие для развития."""
    action: str  # Что делать
    why: str  # Зачем это нужно
    how: str  # Как это делать
    duration: str  # Сколько времени занимает
    frequency: str  # Как часто: "ежедневно" / "еженедельно" / "разово"
    metric: str  # Как измерить успех
    priority: int = 1  # 1-3


@dataclass 
class DevelopmentGoal:
    """Цель развития по метрике."""
    metric: str
    metric_name: str
    current_score: float
    target_score: float
    gap: float
    priority: str  # high / medium / low
    priority_reason: str
    actions: list[DevelopmentAction] = field(default_factory=list)
    resources: list[Resource] = field(default_factory=list)
    timeline: str = "30 дней"


@dataclass
class PersonalDevelopmentPlan:
    """Полный персональный план развития."""
    
    # Базовая информация
    role: str
    role_name: str
    experience: str
    experience_name: str
    total_score: int
    
    # Общая оценка и фокус (с дефолтами для гибкости создания)
    overall_assessment: str = ""  # Краткая оценка уровня
    main_focus: str = ""  # Главный фокус развития
    
    # Приоритизированные цели (топ-3)
    primary_goals: list[DevelopmentGoal] = field(default_factory=list)
    
    # Дополнительные цели (остальные зоны роста)
    secondary_goals: list[DevelopmentGoal] = field(default_factory=list)
    
    # План по срокам
    plan_30_days: list[str] = field(default_factory=list)  # Quick wins
    plan_60_days: list[str] = field(default_factory=list)  # Deeper work
    plan_90_days: list[str] = field(default_factory=list)  # Mastery
    
    # Ключевые метрики успеха
    success_metrics: list[str] = field(default_factory=list)
    
    # Рекомендации по формату обучения
    learning_style_tips: list[str] = field(default_factory=list)
    
    # Мотивационное сообщение
    motivation_message: str = ""


# ========================================
# БАЗА ЗНАНИЙ: РЕСУРСЫ ПО МЕТРИКАМ
# ========================================

RESOURCES_DB = {
    # === HARD SKILLS ===
    "expertise": {
        "designer": [
            Resource("book", "Дизайн привычных вещей", "Дональд Норман", "", 
                    "Фундамент UX-мышления, понимание когнитивной психологии", "8 часов", "easy", "ru", False, 1),
            Resource("book", "Don't Make Me Think", "Steve Krug", "",
                    "Практичный подход к юзабилити", "4 часа", "easy", "en", False, 1),
            Resource("course", "Google UX Design Professional Certificate", "https://coursera.org/google-ux",
                    "Полный курс от Google, от основ до портфолио", "6 месяцев", "medium", "en", False, 1),
            Resource("practice", "Daily UI Challenge", "https://dailyui.co",
                    "100 дней практики UI-дизайна", "30-60 мин/день", "medium", "en", True, 2),
            Resource("community", "Дизайн-кабак", "https://t.me/designpub",
                    "Сообщество дизайнеров для нетворкинга", "—", "easy", "ru", True, 3),
        ],
        "product": [
            Resource("book", "Inspired", "Marty Cagan", "",
                    "Библия продакт-менеджмента от SVPG", "10 часов", "medium", "en", False, 1),
            Resource("book", "Продакт-менеджмент", "Интерком", "",
                    "Практическое руководство от Intercom", "6 часов", "medium", "ru", False, 1),
            Resource("course", "Reforge Product Strategy", "https://reforge.com",
                    "Продвинутая стратегия продукта", "8 недель", "hard", "en", False, 1),
            Resource("practice", "Разбор продуктовых кейсов", "",
                    "Еженедельный анализ запусков и решений", "2-3 часа/неделю", "medium", "ru", True, 2),
            Resource("article", "Lenny's Newsletter", "https://lennysnewsletter.com",
                    "Лучшие практики от топовых PM", "1 час/неделю", "easy", "en", True, 2),
        ],
    },
    
    "methodology": {
        "designer": [
            Resource("book", "Sprint", "Jake Knapp", "",
                    "Методология дизайн-спринтов от Google Ventures", "6 часов", "easy", "ru", False, 1),
            Resource("course", "IDEO Design Thinking", "https://ideou.com",
                    "Оригинальный курс Design Thinking от IDEO", "4 недели", "medium", "en", False, 1),
            Resource("book", "Lean UX", "Jeff Gothelf", "",
                    "Применение Lean в дизайне", "5 часов", "medium", "en", False, 2),
            Resource("practice", "Проведение дизайн-спринта", "",
                    "Организуй 5-дневный спринт для реального проекта", "1 неделя", "hard", "ru", True, 1),
        ],
        "product": [
            Resource("book", "Lean Analytics", "Alistair Croll", "",
                    "Работа с метриками на разных стадиях продукта", "8 часов", "medium", "en", False, 1),
            Resource("book", "The Mom Test", "Rob Fitzpatrick", "",
                    "Как правильно проводить custdev", "3 часа", "easy", "en", False, 1),
            Resource("course", "Product Analytics Certification", "https://amplitude.com",
                    "Сертификация по продуктовой аналитике", "20 часов", "medium", "en", True, 1),
            Resource("practice", "Weekly Metrics Review", "",
                    "Еженедельный разбор метрик продукта", "1 час/неделю", "easy", "ru", True, 2),
        ],
    },
    
    "tools_proficiency": {
        "designer": [
            Resource("course", "Figma Advanced Techniques", "https://figma.com/resources",
                    "Продвинутые техники Figma: auto-layout, variants, tokens", "10 часов", "medium", "en", True, 1),
            Resource("practice", "Создание дизайн-системы", "",
                    "Построй полноценную дизайн-систему с токенами", "2-4 недели", "hard", "ru", True, 1),
            Resource("tool", "Tokens Studio for Figma", "https://tokens.studio",
                    "Плагин для работы с дизайн-токенами", "—", "medium", "en", True, 2),
            Resource("course", "Framer Advanced", "https://framer.com",
                    "Интерактивные прототипы и микроанимации", "8 часов", "medium", "en", False, 2),
        ],
        "product": [
            Resource("course", "SQL для продактов", "https://stepik.org",
                    "Самостоятельная работа с данными", "20 часов", "medium", "ru", False, 1),
            Resource("tool", "Amplitude / Mixpanel", "",
                    "Освоение продуктовой аналитики", "10 часов", "medium", "en", True, 1),
            Resource("practice", "A/B тестирование", "",
                    "Запусти и проанализируй 3 A/B теста", "4-8 недель", "medium", "ru", True, 1),
            Resource("course", "Python для анализа данных", "https://practicum.yandex.ru",
                    "Автоматизация аналитики", "3 месяца", "hard", "ru", False, 3),
        ],
    },
    
    # === SOFT SKILLS ===
    "articulation": {
        "all": [
            Resource("book", "Пирамида Минто", "Барбара Минто", "",
                    "Структурирование мыслей и презентаций", "6 часов", "medium", "ru", False, 1),
            Resource("book", "Искусство объяснять", "Ли ЛеФевер", "",
                    "Как доносить сложные идеи просто", "4 часа", "easy", "ru", False, 1),
            Resource("practice", "Toastmasters", "https://toastmasters.org",
                    "Клуб публичных выступлений", "2 часа/неделю", "medium", "en", False, 1),
            Resource("practice", "Elevator Pitch", "",
                    "Отработай 30-секундную презентацию 10 идей", "2 часа", "easy", "ru", True, 2),
            Resource("practice", "Записывай себя", "",
                    "Записывай свои выступления и анализируй", "30 мин/неделю", "easy", "ru", True, 2),
        ],
    },
    
    "self_awareness": {
        "all": [
            Resource("book", "Insight", "Tasha Eurich", "",
                    "Научный подход к развитию самоосознания", "8 часов", "medium", "en", False, 1),
            Resource("book", "Эмоциональный интеллект", "Дэниел Гоулман", "",
                    "Классика по EQ", "10 часов", "medium", "ru", False, 1),
            Resource("practice", "360° Review", "",
                    "Запроси обратную связь от 5+ коллег", "разово", "medium", "ru", True, 1),
            Resource("practice", "Дневник рефлексии", "",
                    "Ежедневно записывай 3 инсайта о себе", "10 мин/день", "easy", "ru", True, 1),
            Resource("practice", "Работа с коучем/ментором", "",
                    "Регулярные сессии для рефлексии", "1-2 часа/месяц", "medium", "ru", False, 2),
        ],
    },
    
    "conflict_handling": {
        "all": [
            Resource("book", "Crucial Conversations", "Patterson et al.", "",
                    "Техники сложных разговоров", "6 часов", "medium", "en", False, 1),
            Resource("book", "Ненасильственное общение", "Маршалл Розенберг", "",
                    "NVC — конструктивный диалог", "6 часов", "medium", "ru", False, 1),
            Resource("book", "Getting to Yes", "Fisher & Ury", "",
                    "Принципы переговоров из Гарварда", "5 часов", "medium", "en", False, 1),
            Resource("practice", "Ролевые игры", "",
                    "Отработай сложные разговоры с коллегой", "1 час/неделю", "medium", "ru", True, 2),
            Resource("practice", "Анализ конфликтов", "",
                    "Разбирай прошлые конфликты: что сработало, что нет", "разово", "easy", "ru", True, 2),
        ],
    },
    
    # === THINKING ===
    "depth": {
        "all": [
            Resource("book", "Thinking, Fast and Slow", "Daniel Kahneman", "",
                    "Понимание когнитивных искажений", "15 часов", "hard", "en", False, 1),
            Resource("book", "Искусство думать", "Рольф Добелли", "",
                    "52 когнитивные ошибки и как их избежать", "4 часа", "easy", "ru", False, 2),
            Resource("practice", "5 Whys", "",
                    "Применяй технику '5 почему' к каждой проблеме", "ежедневно", "easy", "ru", True, 1),
            Resource("practice", "Root Cause Analysis", "",
                    "Fishbone диаграммы для сложных проблем", "по ситуации", "medium", "ru", True, 1),
            Resource("practice", "First Principles Thinking", "",
                    "Разбирай проблемы до базовых принципов", "еженедельно", "hard", "ru", True, 2),
        ],
    },
    
    "structure": {
        "all": [
            Resource("book", "The Pyramid Principle", "Barbara Minto", "",
                    "Структурирование мышления и коммуникации", "6 часов", "medium", "en", False, 1),
            Resource("practice", "MECE Framework", "",
                    "Декомпозируй каждую задачу по MECE", "ежедневно", "medium", "ru", True, 1),
            Resource("practice", "Issue Trees", "",
                    "Строй деревья проблем для сложных задач", "еженедельно", "medium", "ru", True, 1),
            Resource("tool", "Notion / Obsidian", "",
                    "Системы для структурирования знаний", "—", "easy", "ru", True, 2),
            Resource("course", "McKinsey Problem Solving", "https://coursera.org",
                    "Структурный подход от McKinsey", "20 часов", "hard", "en", False, 2),
        ],
    },
    
    "systems_thinking": {
        "all": [
            Resource("book", "Thinking in Systems", "Donella Meadows", "",
                    "Основы системного мышления", "8 часов", "medium", "en", False, 1),
            Resource("book", "Искусство системного мышления", "О'Коннор", "",
                    "Практическое руководство", "6 часов", "medium", "ru", False, 1),
            Resource("practice", "Systems Mapping", "",
                    "Рисуй системные карты для проектов", "еженедельно", "medium", "ru", True, 1),
            Resource("practice", "Causal Loop Diagrams", "",
                    "Строй диаграммы причинно-следственных связей", "по ситуации", "hard", "ru", True, 2),
            Resource("practice", "Second-Order Thinking", "",
                    "Спрашивай 'А что потом?' для каждого решения", "ежедневно", "medium", "ru", True, 1),
        ],
    },
    
    "creativity": {
        "all": [
            Resource("book", "Lateral Thinking", "Edward de Bono", "",
                    "Техники нестандартного мышления", "6 часов", "medium", "en", False, 1),
            Resource("book", "Кради как художник", "Остин Клеон", "",
                    "Как генерировать идеи", "2 часа", "easy", "ru", False, 2),
            Resource("practice", "Crazy 8s", "",
                    "8 идей за 8 минут — ежедневная практика", "10 мин/день", "easy", "ru", True, 1),
            Resource("practice", "Random Input", "",
                    "Используй случайные стимулы для идей", "еженедельно", "easy", "ru", True, 2),
            Resource("practice", "Constraint-based Design", "",
                    "Решай задачи с искусственными ограничениями", "еженедельно", "medium", "ru", True, 2),
            Resource("practice", "Креативный журнал", "",
                    "Записывай минимум 3 идеи в день", "15 мин/день", "easy", "ru", True, 1),
        ],
    },
    
    # === MINDSET ===
    "honesty": {
        "all": [
            Resource("book", "Radical Candor", "Kim Scott", "",
                    "Культура честной обратной связи", "6 часов", "medium", "en", False, 1),
            Resource("book", "Принципы", "Рэй Далио", "",
                    "Радикальная прозрачность в работе", "15 часов", "hard", "ru", False, 2),
            Resource("practice", "Fail Fridays", "",
                    "Еженедельно делись своей ошибкой с командой", "еженедельно", "medium", "ru", True, 1),
            Resource("practice", "Pre-mortem", "",
                    "Анализируй потенциальные провалы до запуска", "по ситуации", "medium", "ru", True, 1),
            Resource("practice", "Blameless Postmortems", "",
                    "Проводи ретро без обвинений", "после инцидентов", "medium", "ru", True, 2),
        ],
    },
    
    "growth_orientation": {
        "all": [
            Resource("book", "Mindset", "Carol Dweck", "",
                    "Growth vs Fixed mindset", "6 часов", "easy", "en", False, 1),
            Resource("book", "Atomic Habits", "James Clear", "",
                    "Как формировать привычки", "5 часов", "easy", "en", False, 1),
            Resource("practice", "Learning Journal", "",
                    "Записывай 3 новых вещи каждый день", "10 мин/день", "easy", "ru", True, 1),
            Resource("practice", "Weekly Learning Goal", "",
                    "Ставь еженедельную цель обучения", "еженедельно", "easy", "ru", True, 1),
            Resource("practice", "Teach to Learn", "",
                    "Объясняй изученное другим", "еженедельно", "medium", "ru", True, 2),
            Resource("practice", "Stretch Assignments", "",
                    "Бери задачи выше текущего уровня", "ежемесячно", "hard", "ru", True, 1),
        ],
    },
}


# ========================================
# ДЕЙСТВИЯ ПО РАЗВИТИЮ
# ========================================

ACTIONS_DB = {
    "expertise": {
        "junior": [
            DevelopmentAction(
                "Изучи 3 кейса лидеров индустрии",
                "Понимание best practices формирует насмотренность",
                "Выбери 3 продукта/проекта и разбери их детально: что, почему, как",
                "4-6 часов",
                "разово",
                "Написанный разбор 3 кейсов",
                1
            ),
            DevelopmentAction(
                "Найди ментора в своей области",
                "Ментор ускоряет развитие в 2-3 раза",
                "Свяжись с 3-5 потенциальными менторами, договорись о регулярных встречах",
                "2-4 недели на поиск",
                "ежемесячно встречи",
                "Регулярные менторские сессии",
                1
            ),
        ],
        "middle": [
            DevelopmentAction(
                "Углубись в свою нишу",
                "T-shaped специалист ценнее универсала",
                "Выбери 1-2 темы и стань в них экспертом (статьи, выступления)",
                "3-6 месяцев",
                "постоянно",
                "Статья или выступление по теме",
                1
            ),
        ],
        "senior": [
            DevelopmentAction(
                "Начни делиться экспертизой",
                "Обучая других, углубляешь своё понимание",
                "Веди внутренние митапы, пиши статьи, менторь junior",
                "2-4 часа/неделю",
                "еженедельно",
                "2+ выступления или статьи в месяц",
                1
            ),
        ],
        "lead": [
            DevelopmentAction(
                "Выстрой систему передачи знаний",
                "Масштабирование экспертизы на команду",
                "Создай программу онбординга и development plan для команды",
                "2-4 недели",
                "разово + поддержка",
                "Работающая система развития в команде",
                1
            ),
        ],
    },
    
    "depth": {
        "all": [
            DevelopmentAction(
                "Практикуй технику '5 почему'",
                "Добираешься до корневых причин, а не симптомов",
                "К каждой проблеме задавай вопрос 'Почему?' минимум 5 раз подряд",
                "5 минут на проблему",
                "ежедневно",
                "Найдено 3+ корневых причины на этой неделе",
                1
            ),
            DevelopmentAction(
                "Веди журнал решений",
                "Рефлексия улучшает качество мышления",
                "Записывай важные решения: контекст, альтернативы, выбор, результат",
                "15 минут",
                "еженедельно",
                "10+ записей в журнале за месяц",
                2
            ),
        ],
    },
    
    "creativity": {
        "all": [
            DevelopmentAction(
                "Ежедневная практика идей",
                "Креативность — это мышца, которую нужно качать",
                "Каждый день генерируй 10 идей на случайную тему (метод Джеймса Альтучера)",
                "15 минут",
                "ежедневно",
                "70+ идей за неделю",
                1
            ),
            DevelopmentAction(
                "Crazy 8s для рабочих задач",
                "Быстрая генерация альтернатив",
                "Для каждой задачи нарисуй 8 разных решений за 8 минут",
                "8 минут",
                "по ситуации",
                "Использовал Crazy 8s для 5 задач",
                1
            ),
        ],
    },
    
    "self_awareness": {
        "all": [
            DevelopmentAction(
                "Запроси 360° feedback",
                "Видишь слепые зоны через глаза других",
                "Попроси 5-7 коллег ответить на 3 вопроса: что делаю хорошо, что улучшить, что удивляет",
                "2-3 дня",
                "ежеквартально",
                "Получен feedback от 5+ человек",
                1
            ),
            DevelopmentAction(
                "Веди дневник рефлексии",
                "Регулярная рефлексия развивает самоосознание",
                "Каждый вечер записывай: что получилось, что нет, что узнал о себе",
                "10 минут",
                "ежедневно",
                "30+ записей за месяц",
                1
            ),
        ],
    },
    
    "articulation": {
        "all": [
            DevelopmentAction(
                "Записывай свои объяснения",
                "Видишь себя со стороны",
                "Объясни сложную концепцию на камеру, пересмотри, улучши",
                "30 минут",
                "еженедельно",
                "4 записанных объяснения за месяц",
                1
            ),
            DevelopmentAction(
                "Практика Elevator Pitch",
                "Умение быстро доносить суть",
                "Подготовь 30-секундную версию каждого проекта/идеи",
                "15 минут",
                "по ситуации",
                "5+ отработанных питчей",
                2
            ),
        ],
    },
    
    "growth_orientation": {
        "all": [
            DevelopmentAction(
                "Создай Personal Learning Plan",
                "Структурированное развитие эффективнее хаотичного",
                "Определи 3 навыка для развития, найди ресурсы, поставь сроки",
                "2-3 часа",
                "ежеквартально",
                "Документ с планом и прогрессом",
                1
            ),
            DevelopmentAction(
                "Бери stretch-задачи",
                "Рост происходит за пределами зоны комфорта",
                "Возьми задачу на 20-30% сложнее текущего уровня",
                "зависит от задачи",
                "ежемесячно",
                "1 stretch-задача в месяц",
                1
            ),
        ],
    },
    
    "honesty": {
        "all": [
            DevelopmentAction(
                "Практикуй 'Fail Fridays'",
                "Нормализация ошибок создаёт культуру обучения",
                "Каждую пятницу делись с командой одной своей ошибкой и выводом",
                "10 минут",
                "еженедельно",
                "4+ публичных разбора ошибок за месяц",
                1
            ),
        ],
    },
}


def _get_resources_for_metric(metric: str, role: str) -> list[Resource]:
    """Получить ресурсы для метрики и роли."""
    metric_resources = RESOURCES_DB.get(metric, {})
    
    # Сначала ищем для конкретной роли
    if role in metric_resources:
        return metric_resources[role]
    
    # Потом общие
    if "all" in metric_resources:
        return metric_resources["all"]
    
    # Если для роли designer нет, пробуем product и наоборот
    for r in ["designer", "product"]:
        if r in metric_resources:
            return metric_resources[r]
    
    return []


def _get_actions_for_metric(metric: str, experience: str) -> list[DevelopmentAction]:
    """Получить действия для метрики и уровня."""
    metric_actions = ACTIONS_DB.get(metric, {})
    
    # Сначала для уровня
    actions = metric_actions.get(experience, [])
    
    # Добавляем общие
    actions.extend(metric_actions.get("all", []))
    
    return actions


def _prioritize_gaps(
    raw_averages: dict[str, float],
    experience: str,
) -> list[tuple[str, float, str]]:
    """
    Приоритизировать зоны развития.
    
    Returns:
        Список (metric, gap, priority) отсортированный по важности
    """
    # Веса категорий по важности для разных уровней
    category_weights = {
        "junior": {
            "expertise": 1.5, "methodology": 1.3, "tools_proficiency": 1.2,
            "articulation": 1.0, "self_awareness": 1.0, "conflict_handling": 0.8,
            "depth": 1.2, "structure": 1.3, "systems_thinking": 0.9, "creativity": 0.8,
            "honesty": 1.0, "growth_orientation": 1.4,
        },
        "middle": {
            "expertise": 1.3, "methodology": 1.2, "tools_proficiency": 1.0,
            "articulation": 1.2, "self_awareness": 1.3, "conflict_handling": 1.2,
            "depth": 1.4, "structure": 1.2, "systems_thinking": 1.3, "creativity": 1.1,
            "honesty": 1.1, "growth_orientation": 1.2,
        },
        "senior": {
            "expertise": 1.1, "methodology": 1.0, "tools_proficiency": 0.8,
            "articulation": 1.3, "self_awareness": 1.4, "conflict_handling": 1.3,
            "depth": 1.3, "structure": 1.1, "systems_thinking": 1.5, "creativity": 1.2,
            "honesty": 1.2, "growth_orientation": 1.1,
        },
        "lead": {
            "expertise": 1.0, "methodology": 0.9, "tools_proficiency": 0.7,
            "articulation": 1.4, "self_awareness": 1.5, "conflict_handling": 1.4,
            "depth": 1.2, "structure": 1.0, "systems_thinking": 1.5, "creativity": 1.1,
            "honesty": 1.3, "growth_orientation": 1.0,
        },
    }
    
    weights = category_weights.get(experience, category_weights["middle"])
    
    # Считаем приоритетный gap = (10 - score) * weight
    gaps = []
    for metric, score in raw_averages.items():
        if metric not in ALL_METRICS:
            continue
        gap = (10 - score) * weights.get(metric, 1.0)
        
        if gap > 4:
            priority = "high"
        elif gap > 2:
            priority = "medium"
        else:
            priority = "low"
        
        gaps.append((metric, 10 - score, priority, gap))
    
    # Сортируем по weighted gap
    gaps.sort(key=lambda x: x[3], reverse=True)
    
    return [(m, g, p) for m, g, p, _ in gaps]


def _generate_timeline_plan(goals: list[DevelopmentGoal], experience: str) -> tuple[list[str], list[str], list[str]]:
    """Сгенерировать план на 30/60/90 дней."""
    plan_30 = []
    plan_60 = []
    plan_90 = []
    
    # 30 дней — quick wins и формирование привычек
    plan_30.append("📚 Прочитать 1 книгу из рекомендаций")
    plan_30.append("✅ Внедрить 2 ежедневные практики")
    
    if goals:
        top_goal = goals[0]
        plan_30.append(f"🎯 Фокус на {top_goal.metric_name}: выполнить первое действие")
        
        if top_goal.actions:
            for action in top_goal.actions[:2]:
                if "ежедневно" in action.frequency or "разово" in action.frequency:
                    plan_30.append(f"▸ {action.action}")
    
    # 60 дней — deeper work
    plan_60.append("📖 Изучить 2 книги/курса из списка")
    plan_60.append("🔄 Закрепить ежедневные практики в привычки")
    
    if len(goals) > 1:
        plan_60.append(f"🎯 Добавить фокус на {goals[1].metric_name}")
    
    plan_60.append("📊 Провести промежуточную самооценку")
    
    # 90 дней — mastery
    plan_90.append("🏆 Достигнуть измеримого результата по главной цели")
    plan_90.append("📝 Написать статью или провести митап по изученному")
    plan_90.append("🔄 Пройти повторную диагностику для оценки прогресса")
    
    if experience in ["senior", "lead"]:
        plan_90.append("👥 Начать менторить кого-то в своих сильных областях")
    
    return plan_30, plan_60, plan_90


def build_pdp(
    role: str,
    role_name: str,
    experience: str,
    experience_name: str,
    total_score: int,
    raw_averages: dict[str, float],
    strengths: list[str],
) -> PersonalDevelopmentPlan:
    """
    Построить персональный план развития.
    
    Args:
        role: designer / product
        role_name: Дизайнер / Продакт-менеджер
        experience: junior / middle / senior / lead
        experience_name: до 1 года / 1-3 года / ...
        total_score: Общий балл 0-100
        raw_averages: Средние по 12 метрикам
        strengths: Топ сильных сторон
    
    Returns:
        PersonalDevelopmentPlan
    """
    pdp = PersonalDevelopmentPlan(
        role=role,
        role_name=role_name,
        experience=experience,
        experience_name=experience_name,
        total_score=total_score,
    )
    
    # Общая оценка
    if total_score >= 80:
        pdp.overall_assessment = "Отличный уровень! Фокус на масштабировании влияния."
        pdp.main_focus = "Развитие лидерских качеств и передача экспертизы"
    elif total_score >= 60:
        pdp.overall_assessment = "Хороший уровень с потенциалом роста."
        pdp.main_focus = "Углубление экспертизы и развитие soft skills"
    elif total_score >= 40:
        pdp.overall_assessment = "Есть база, нужна фокусная работа над ключевыми навыками."
        pdp.main_focus = "Укрепление фундамента и практика"
    else:
        pdp.overall_assessment = "Начало пути — важно сфокусироваться на основах."
        pdp.main_focus = "Изучение основ и наработка практики"
    
    # Приоритизируем gaps
    prioritized = _prioritize_gaps(raw_averages, experience)
    
    # Строим цели
    for metric, gap, priority in prioritized[:3]:
        goal = DevelopmentGoal(
            metric=metric,
            metric_name=METRIC_NAMES_RU.get(metric, metric),
            current_score=raw_averages.get(metric, 5),
            target_score=min(10, raw_averages.get(metric, 5) + 2),
            gap=gap,
            priority=priority,
            priority_reason=f"Важно для {experience_name}" if priority == "high" else "Зона роста",
            actions=_get_actions_for_metric(metric, experience),
            resources=_get_resources_for_metric(metric, role)[:3],
            timeline="30 дней" if priority == "high" else "60 дней",
        )
        pdp.primary_goals.append(goal)
    
    # Secondary goals
    for metric, gap, priority in prioritized[3:6]:
        goal = DevelopmentGoal(
            metric=metric,
            metric_name=METRIC_NAMES_RU.get(metric, metric),
            current_score=raw_averages.get(metric, 5),
            target_score=min(10, raw_averages.get(metric, 5) + 1.5),
            gap=gap,
            priority=priority,
            priority_reason="Дополнительная зона развития",
            resources=_get_resources_for_metric(metric, role)[:2],
            timeline="90 дней",
        )
        pdp.secondary_goals.append(goal)
    
    # Timeline план
    pdp.plan_30_days, pdp.plan_60_days, pdp.plan_90_days = _generate_timeline_plan(
        pdp.primary_goals, experience
    )
    
    # Метрики успеха
    pdp.success_metrics = [
        f"📈 Повысить {pdp.primary_goals[0].metric_name} с {pdp.primary_goals[0].current_score:.1f} до {pdp.primary_goals[0].target_score:.1f}" if pdp.primary_goals else "",
        "📚 Изучить 3 книги/курса из рекомендаций",
        "✅ Выполнять ежедневные практики 80% дней",
        "🔄 Пройти повторную диагностику через 90 дней",
    ]
    pdp.success_metrics = [m for m in pdp.success_metrics if m]
    
    # Learning style tips
    pdp.learning_style_tips = [
        "📖 Чередуй теорию и практику (30% теории, 70% практики)",
        "📝 Веди заметки и делай выжимки из материалов",
        "👥 Обсуждай изученное с коллегами",
        "🔄 Применяй новое в рабочих задачах в тот же день",
    ]
    
    # Мотивация
    motivation_messages = {
        "junior": "🚀 Ты в начале отличного пути! Каждый эксперт когда-то начинал с нуля.",
        "middle": "💪 У тебя хорошая база — пора выходить на новый уровень!",
        "senior": "🎯 Ты уже многого достиг — время влиять на индустрию!",
        "lead": "👑 Твоя миссия — вырастить следующее поколение экспертов!",
    }
    pdp.motivation_message = motivation_messages.get(experience, motivation_messages["middle"])
    
    return pdp


def format_pdp_text(pdp: PersonalDevelopmentPlan) -> str:
    """
    Форматировать PDP для Telegram.
    Профессиональный формат без лишних эмодзи, только 30 дней.
    """
    
    # Header — минималистичный
    header = f"""<b>ПЛАН РАЗВИТИЯ НА 30 ДНЕЙ</b>

Текущий уровень: <b>{pdp.total_score}/100</b>
Главный фокус: <b>{pdp.main_focus}</b>

"""
    
    # Приоритетные зоны (без эмодзи, с конкретикой)
    goals_text = "<b>ПРИОРИТЕТНЫЕ ЗОНЫ</b>\n\n"
    
    for i, goal in enumerate(pdp.primary_goals[:3], 1):
        # Приоритет текстом
        priority_text = "высокий" if goal.priority == "high" else "средний" if goal.priority == "medium" else "низкий"
        
        goals_text += f"<b>{i}. {goal.metric_name}</b>\n"
        goals_text += f"   Уровень: {goal.current_score:.1f}/10 → цель {goal.target_score:.1f}/10\n"
        goals_text += f"   Приоритет: {priority_text}\n"
        
        if goal.priority_reason:
            goals_text += f"   Почему важно: {goal.priority_reason}\n"
        
        # Конкретные действия (максимум 3)
        if goal.actions:
            goals_text += "\n   <b>Действия:</b>\n"
            for j, action in enumerate(goal.actions[:3], 1):
                action_text = action.action if isinstance(action, object) and hasattr(action, 'action') else str(action)
                goals_text += f"   {j}. {action_text}\n"
        
        # Ресурсы (без эмодзи, с авторами)
        if goal.resources:
            goals_text += "\n   <b>Ресурсы:</b>\n"
            for res in goal.resources[:2]:
                res_type = res.type.upper() if hasattr(res, 'type') else "РЕСУРС"
                res_title = res.title if hasattr(res, 'title') else str(res)
                res_author = f" — {res.author}" if hasattr(res, 'author') and res.author else ""
                goals_text += f"   [{res_type}] {res_title}{res_author}\n"
        
        goals_text += "\n"
    
    # План на 30 дней (развёрнутый)
    timeline_text = "<b>ПЛАН ДЕЙСТВИЙ (30 ДНЕЙ)</b>\n\n"
    
    if pdp.plan_30_days:
        for i, item in enumerate(pdp.plan_30_days, 1):
            # Убираем эмодзи из начала
            clean_item = item.lstrip("▸•📚✅🎯 ")
            timeline_text += f"{i}. {clean_item}\n"
    else:
        # Fallback если нет плана
        timeline_text += "1. Изучить рекомендованные материалы\n"
        timeline_text += "2. Применить на практике минимум 2 подхода\n"
        timeline_text += "3. Запросить обратную связь от коллег\n"
    
    # Метрики успеха (конкретные)
    metrics_text = "\n<b>КРИТЕРИИ УСПЕХА</b>\n\n"
    
    if pdp.success_metrics:
        for i, metric in enumerate(pdp.success_metrics[:4], 1):
            clean_metric = metric.lstrip("▸•📈✅🔄📚 ")
            metrics_text += f"{i}. {clean_metric}\n"
    else:
        metrics_text += "1. Повышение балла при повторной диагностике\n"
        metrics_text += "2. Положительная обратная связь от коллег\n"
        metrics_text += "3. Успешное применение новых подходов в проекте\n"
    
    # Финальная рекомендация
    footer = "\n<i>Рекомендуем пройти повторную диагностику через 30 дней для оценки прогресса.</i>"
    
    return header + goals_text + timeline_text + metrics_text + footer


def format_pdp_short(pdp: PersonalDevelopmentPlan) -> str:
    """Краткий формат PDP."""
    if not pdp.primary_goals:
        return ""
    
    goals_list = ", ".join([g.metric_name for g in pdp.primary_goals[:3]])
    return f"🎯 Фокус: {goals_list}"

