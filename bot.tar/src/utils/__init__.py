"""Утилиты."""
from src.utils.pdf_generator import generate_pdf_report

__all__ = ["generate_pdf_report"]

