"""
Тестовый скрипт для проверки аналитики без прохождения диагностики.
Запуск: python test_analytics.py
"""
import asyncio
import sys

# Мок-данные как будто прошли диагностику
MOCK_RAW_AVERAGES = {
    "expertise": 8.0,
    "methodology": 7.5,
    "tools_proficiency": 6.0,
    "articulation": 9.0,
    "self_awareness": 8.5,
    "conflict_handling": 7.0,
    "depth": 8.0,
    "structure": 8.5,
    "systems_thinking": 7.5,
    "creativity": 6.5,
    "honesty": 9.0,
    "growth_orientation": 8.0,
}

MOCK_SCORES = {
    "hard_skills": 22,
    "soft_skills": 20,
    "thinking": 19,
    "mindset": 17,
    "total": 78,
    "raw_averages": MOCK_RAW_AVERAGES,
}


def test_competency_profile():
    """Тест построения профиля компетенций."""
    print("\n" + "="*60)
    print("🧪 Тест: CompetencyProfile")
    print("="*60)
    
    try:
        from src.analytics.competency_profile import build_profile
        
        # Мок analysis_history (как будто было 10 ответов)
        mock_analysis_history = [
            {"scores": MOCK_RAW_AVERAGES, "patterns": {"authentic": True}, "detected_patterns": ["authentic"]}
            for _ in range(10)
        ]
        
        profile = build_profile(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            experience_name="3-6 лет",
            scores=MOCK_SCORES,
            analysis_history=mock_analysis_history,
        )
        
        print(f"✅ Профиль создан успешно!")
        print(f"   - Роль: {profile.role_name}")
        print(f"   - Уровень: {profile.level}")
        print(f"   - Тип мышления: {profile.thinking_style}")
        print(f"   - Мотивация: {profile.motivation_driver}")
        print(f"   - Сильные стороны: {profile.strengths[:3]}")
        print(f"   - Зоны роста: {profile.growth_areas[:3]}")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_pdp():
    """Тест построения плана развития."""
    print("\n" + "="*60)
    print("🧪 Тест: PersonalDevelopmentPlan (PDP)")
    print("="*60)
    
    try:
        from src.analytics.pdp import build_pdp
        
        pdp = build_pdp(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            experience_name="3-6 лет",
            total_score=78,
            raw_averages=MOCK_RAW_AVERAGES,
            strengths=["articulation", "honesty", "self_awareness"],
        )
        
        print(f"✅ PDP создан успешно!")
        print(f"   - Оценка: {pdp.overall_assessment}")
        print(f"   - Фокус: {pdp.main_focus}")
        print(f"   - Целей: {len(pdp.primary_goals)}")
        if pdp.primary_goals:
            print(f"   - Первая цель: {pdp.primary_goals[0].metric_name}")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_json_parser():
    """Тест парсера JSON из markdown."""
    print("\n" + "="*60)
    print("🧪 Тест: robust_json_parse")
    print("="*60)
    
    try:
        from src.ai.answer_analyzer import robust_json_parse
        
        # Тест 1: JSON в markdown блоке
        test1 = '''```json
{
  "scores": {
    "expertise": 8,
    "methodology": 7
  },
  "patterns": {"authentic": true}
}
```'''
        result1 = robust_json_parse(test1)
        assert "scores" in result1, "Должен быть ключ 'scores'"
        print("✅ Тест 1 (markdown блок): OK")
        
        # Тест 2: Чистый JSON
        test2 = '{"scores": {"expertise": 9}, "patterns": {}}'
        result2 = robust_json_parse(test2)
        assert result2["scores"]["expertise"] == 9
        print("✅ Тест 2 (чистый JSON): OK")
        
        # Тест 3: JSON с trailing text
        test3 = '{"key": "value"} и какой-то текст после'
        result3 = robust_json_parse(test3)
        assert result3["key"] == "value"
        print("✅ Тест 3 (trailing text): OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_detect_style():
    """Тест определения стиля (исправленный баг с 'balanced')."""
    print("\n" + "="*60)
    print("🧪 Тест: _detect_style (fix KeyError 'balanced')")
    print("="*60)
    
    try:
        from src.analytics.competency_profile import (
            _detect_style,
            THINKING_STYLES,
            COMMUNICATION_STYLES,
            MOTIVATION_DRIVERS,
            DECISION_STYLES,
        )
        
        # Тест с низкими оценками (раньше падал с KeyError: 'balanced')
        low_scores = {k: 3.0 for k in MOCK_RAW_AVERAGES}
        
        for name, styles in [
            ("THINKING_STYLES", THINKING_STYLES),
            ("COMMUNICATION_STYLES", COMMUNICATION_STYLES),
            ("MOTIVATION_DRIVERS", MOTIVATION_DRIVERS),
            ("DECISION_STYLES", DECISION_STYLES),
        ]:
            style, desc = _detect_style(low_scores, styles)
            print(f"✅ {name}: '{style}' - OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_share_card():
    """Тест генерации карточки для шеринга."""
    print("\n" + "="*60)
    print("🧪 Тест: ShareCard")
    print("="*60)
    
    try:
        from src.utils.share_card import generate_share_card_simple
        
        image_bytes = generate_share_card_simple(
            total_score=78,
            role_name="Дизайнер",
            level_name="Senior",
        )
        
        print(f"✅ Карточка сгенерирована: {len(image_bytes)} байт")
        
        # Сохраним для проверки
        with open("test_share_card.png", "wb") as f:
            f.write(image_bytes)
        print("   Сохранено в test_share_card.png")
        
        return True
        
    except ImportError as e:
        print(f"⚠️ Pillow не установлен: {e}")
        return True  # Не критично
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_formatters():
    """Тест форматтеров текста."""
    print("\n" + "="*60)
    print("🧪 Тест: Форматтеры (profile, pdp, benchmark)")
    print("="*60)
    
    errors = []
    
    # 1. Profile formatters
    try:
        from src.analytics.competency_profile import (
            build_profile, format_profile_text, format_profile_short
        )
        
        mock_analysis_history = [
            {"scores": MOCK_RAW_AVERAGES, "patterns": {"authentic": True}, "detected_patterns": ["authentic"]}
            for _ in range(10)
        ]
        
        profile = build_profile(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            experience_name="3-6 лет",
            scores=MOCK_SCORES,
            analysis_history=mock_analysis_history,
        )
        
        text = format_profile_text(profile)
        short = format_profile_short(profile)
        
        assert len(text) > 100, "format_profile_text слишком короткий"
        assert len(short) > 50, "format_profile_short слишком короткий"
        print(f"✅ format_profile_text: {len(text)} символов")
        print(f"✅ format_profile_short: {len(short)} символов")
        
    except Exception as e:
        errors.append(f"Profile formatters: {e}")
        print(f"❌ Profile formatters: {e}")
    
    # 2. PDP formatters
    try:
        from src.analytics.pdp import build_pdp, format_pdp_text, format_pdp_short
        
        pdp = build_pdp(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            experience_name="3-6 лет",
            total_score=78,
            raw_averages=MOCK_RAW_AVERAGES,
            strengths=["articulation", "honesty"],
        )
        
        text = format_pdp_text(pdp)
        short = format_pdp_short(pdp)
        
        assert len(text) > 100, "format_pdp_text слишком короткий"
        assert len(short) > 50, "format_pdp_short слишком короткий"
        print(f"✅ format_pdp_text: {len(text)} символов")
        print(f"✅ format_pdp_short: {len(short)} символов")
        
    except Exception as e:
        errors.append(f"PDP formatters: {e}")
        print(f"❌ PDP formatters: {e}")
    
    # 3. Benchmark formatters (без БД — просто структуры)
    try:
        from src.analytics.benchmark import (
            BenchmarkResult, format_benchmark_text, format_benchmark_short
        )
        
        # Создаём мок BenchmarkResult (с правильными полями)
        benchmark = BenchmarkResult(
            has_enough_data=True,
            overall_percentile=75,
            overall_total_sessions=500,
            role_percentile=80,
            role_total_sessions=150,
            role_name="Дизайнер",
            experience_percentile=70,
            experience_total_sessions=100,
            experience_name="3-6 лет",
            combined_percentile=75,
            combined_total_sessions=50,
            avg_score_overall=65.0,
        )
        
        text = format_benchmark_text(benchmark, user_score=78)
        short = format_benchmark_short(benchmark)
        
        assert len(text) > 50, "format_benchmark_text слишком короткий"
        assert len(short) > 30, "format_benchmark_short слишком короткий"
        print(f"✅ format_benchmark_text: {len(text)} символов")
        print(f"✅ format_benchmark_short: {len(short)} символов")
        
    except Exception as e:
        errors.append(f"Benchmark formatters: {e}")
        print(f"❌ Benchmark formatters: {e}")
    
    if errors:
        return False
    return True


def test_pdf_generator():
    """Тест генерации PDF отчёта."""
    print("\n" + "="*60)
    print("🧪 Тест: PDF Generator")
    print("="*60)
    
    try:
        from src.utils.pdf_generator import generate_pdf_report
        
        # Мок данных
        mock_conversation = [
            {"role": "bot", "text": "Расскажите о своём опыте работы с дизайн-системами?"},
            {"role": "user", "text": "Я создавал дизайн-систему для продукта с 50+ компонентами..."},
        ] * 5  # 10 Q&A
        
        mock_profile_data = {
            "level": "Senior",
            "level_match": "exceeds",
            "thinking_style": "analytical",
            "communication_style": "direct",
            "motivation_driver": "growth",
            "strengths": ["articulation", "honesty"],
            "growth_areas": ["tools_proficiency", "creativity"],
        }
        
        mock_pdp_data = {
            "overall_assessment": "Отличный уровень!",
            "main_focus": "Масштабирование влияния",
            "primary_goals": [
                {"metric_name": "Креативность", "current_score": 6.5, "target_score": 8.5}
            ],
        }
        
        pdf_bytes = generate_pdf_report(
            role_name="Дизайнер",
            experience="3-6 лет",
            scores=MOCK_SCORES,
            report_text="<b>Отличный результат!</b> Вы показали высокий уровень экспертизы.",
            conversation_history=mock_conversation,
            user_name="Тестовый Пользователь",
            profile_data=mock_profile_data,
            pdp_data=mock_pdp_data,
            raw_averages=MOCK_RAW_AVERAGES,
        )
        
        print(f"✅ PDF сгенерирован: {len(pdf_bytes)} байт")
        
        # Сохраним для проверки
        with open("test_report.pdf", "wb") as f:
            f.write(pdf_bytes)
        print("   Сохранено в test_report.pdf")
        
        return True
        
    except ImportError as e:
        print(f"⚠️ ReportLab не установлен: {e}")
        return True  # Не критично
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_keyboards():
    """Тест генерации клавиатур (часто падают при неправильных данных)."""
    print("\n" + "="*60)
    print("🧪 Тест: Keyboards")
    print("="*60)
    
    errors = []
    
    try:
        from src.bot.keyboards.inline import (
            get_role_keyboard,
            get_experience_keyboard,
            get_confirm_answer_keyboard,
            get_pause_keyboard,
            get_error_retry_keyboard,
            get_session_recovery_keyboard,
        )
        
        # Все клавиатуры должны создаваться без ошибок
        kb1 = get_role_keyboard()
        print(f"✅ get_role_keyboard: {len(kb1.inline_keyboard)} рядов")
        
        kb2 = get_experience_keyboard()
        print(f"✅ get_experience_keyboard: {len(kb2.inline_keyboard)} рядов")
        
        kb3 = get_confirm_answer_keyboard()
        print(f"✅ get_confirm_answer_keyboard: {len(kb3.inline_keyboard)} рядов")
        
        kb4 = get_pause_keyboard()
        print(f"✅ get_pause_keyboard: {len(kb4.inline_keyboard)} рядов")
        
        kb5 = get_error_retry_keyboard()
        print(f"✅ get_error_retry_keyboard: {len(kb5.inline_keyboard)} рядов")
        
        kb6 = get_session_recovery_keyboard(session_id=1, current_q=5, total_q=10)
        print(f"✅ get_session_recovery_keyboard: {len(kb6.inline_keyboard)} рядов")
        
    except Exception as e:
        errors.append(str(e))
        print(f"❌ Keyboards: {e}")
        import traceback
        traceback.print_exc()
    
    return len(errors) == 0


def test_prompts():
    """Тест системных промптов (не должны быть пустыми)."""
    print("\n" + "="*60)
    print("🧪 Тест: System Prompts")
    print("="*60)
    
    errors = []
    
    try:
        from src.core.prompts.system import (
            get_question_prompt,
            get_analysis_prompt,
        )
        
        # Вопрос (первый)
        p1 = get_question_prompt(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            question_number=1,
            conversation_history=[],
            analysis_history=[],
        )
        assert len(p1) > 0, "get_question_prompt пустой"
        assert p1[0].get("content"), "Нет content в промпте"
        print(f"✅ get_question_prompt (первый): {len(p1)} сообщений")
        
        # Вопрос (следующий)
        history = [{"question": "Расскажи о своём опыте?", "answer": "Работал 5 лет в Авито..."}]
        analysis = [{"scores": MOCK_RAW_AVERAGES}]
        
        p2 = get_question_prompt(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            question_number=5,
            conversation_history=history,
            analysis_history=analysis,
        )
        assert len(p2) > 0, "get_question_prompt пустой"
        print(f"✅ get_question_prompt (следующий): {len(p2)} сообщений")
        
        # Анализ
        p3 = get_analysis_prompt("Вопрос?", "Ответ.", "designer")
        assert len(p3) > 0, "get_analysis_prompt пустой"
        print(f"✅ get_analysis_prompt: {len(p3)} сообщений")
        
    except Exception as e:
        errors.append(str(e))
        print(f"❌ Prompts: {e}")
        import traceback
        traceback.print_exc()
    
    return len(errors) == 0


def test_dataclass_serialization():
    """Тест сериализации dataclass в dict (для PDF/JSON)."""
    print("\n" + "="*60)
    print("🧪 Тест: Dataclass Serialization")
    print("="*60)
    
    errors = []
    
    try:
        from dataclasses import asdict
        from src.analytics.competency_profile import build_profile, CompetencyProfile
        from src.analytics.pdp import build_pdp, PersonalDevelopmentPlan
        from src.analytics.benchmark import BenchmarkResult
        
        # 1. CompetencyProfile -> dict
        mock_history = [
            {"scores": MOCK_RAW_AVERAGES, "patterns": {}, "detected_patterns": []}
            for _ in range(10)
        ]
        profile = build_profile(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            experience_name="3-6 лет",
            scores=MOCK_SCORES,
            analysis_history=mock_history,
        )
        profile_dict = asdict(profile)
        assert isinstance(profile_dict, dict), "Profile не конвертируется в dict"
        assert "total_score" in profile_dict, "Нет total_score в dict"
        print(f"✅ CompetencyProfile -> dict: {len(profile_dict)} ключей")
        
        # 2. PDP -> dict
        pdp = build_pdp(
            role="designer",
            role_name="Дизайнер",
            experience="senior",
            experience_name="3-6 лет",
            total_score=78,
            raw_averages=MOCK_RAW_AVERAGES,
            strengths=["articulation"],
        )
        pdp_dict = asdict(pdp)
        assert isinstance(pdp_dict, dict), "PDP не конвертируется в dict"
        print(f"✅ PersonalDevelopmentPlan -> dict: {len(pdp_dict)} ключей")
        
        # 3. BenchmarkResult -> dict
        benchmark = BenchmarkResult(has_enough_data=True, overall_percentile=75)
        bench_dict = asdict(benchmark)
        assert isinstance(bench_dict, dict), "Benchmark не конвертируется в dict"
        print(f"✅ BenchmarkResult -> dict: {len(bench_dict)} ключей")
        
    except Exception as e:
        errors.append(str(e))
        print(f"❌ Serialization: {e}")
        import traceback
        traceback.print_exc()
    
    return len(errors) == 0


def test_error_recovery():
    """Тест error recovery utilities."""
    print("\n" + "="*60)
    print("🧪 Тест: Error Recovery Utils")
    print("="*60)
    
    try:
        from src.utils.error_recovery import (
            ErrorType,
            get_error_message,
        )
        
        # Тест error messages
        for error_type in ErrorType:
            msg = get_error_message(error_type)
            assert len(msg) > 10, f"Сообщение для {error_type} слишком короткое"
        print(f"✅ get_error_message: {len(list(ErrorType))} типов ошибок OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Error Recovery: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_accessibility():
    """Тест accessibility utilities."""
    print("\n" + "="*60)
    print("🧪 Тест: Accessibility Utils")
    print("="*60)
    
    try:
        from src.utils.accessibility import detect_language
        
        # Тест определения языка
        assert detect_language("Привет, как дела?") == "ru"
        assert detect_language("Hello, how are you?") == "en"
        print("✅ detect_language: OK")
        
        return True
        
    except ImportError:
        print("⚠️ accessibility module не найден (не критично)")
        return True
    except Exception as e:
        print(f"❌ Accessibility: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_progress_report():
    """Тест прогресс-репорта."""
    print("\n" + "="*60)
    print("🧪 Тест: Progress Report")
    print("="*60)
    
    try:
        from src.analytics.progress import (
            ProgressReport,
            format_progress_text,
            format_progress_short,
        )
        
        # Создаём мок ProgressReport с правильными полями
        report = ProgressReport(
            has_progress_data=True,
            sessions_count=3,
            first_score=60,
            last_score=78,
            score_change=18,
            score_change_percent=30.0,
        )
        
        text = format_progress_text(report)
        short = format_progress_short(report)
        
        assert len(text) > 20, "format_progress_text слишком короткий"
        print(f"✅ format_progress_text: {len(text)} символов")
        print(f"✅ format_progress_short: {len(short)} символов")
        
        return True
        
    except Exception as e:
        print(f"❌ Progress Report: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_answer_validation():
    """Тест валидации длины ответа."""
    print("\n" + "="*60)
    print("🧪 Тест: Answer Validation (MIN/MAX length)")
    print("="*60)
    
    try:
        MIN_ANSWER_LENGTH = 50
        MAX_ANSWER_LENGTH = 4000
        
        test_cases = [
            ("Да", False, "слишком короткий (2 симв)"),
            ("a" * 49, False, "граница min-1 (49)"),
            ("a" * 50, True, "ровно min (50)"),
            ("a" * 100, True, "нормальный (100)"),
            ("a" * 4000, True, "ровно max (4000)"),
            ("a" * 4001, False, "превышает max (4001)"),
        ]
        
        passed = 0
        for answer, expected_valid, desc in test_cases:
            is_valid = MIN_ANSWER_LENGTH <= len(answer) <= MAX_ANSWER_LENGTH
            if is_valid == expected_valid:
                passed += 1
                print(f"  ✅ {desc}")
            else:
                print(f"  ❌ {desc}: ожидалось {expected_valid}, получено {is_valid}")
        
        print(f"\n  Пройдено {passed}/{len(test_cases)}")
        return passed == len(test_cases)
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


def test_pdp_30_days_format():
    """Тест нового формата PDP (только 30 дней)."""
    print("\n" + "="*60)
    print("🧪 Тест: PDP 30 Days Format")
    print("="*60)
    
    try:
        from src.analytics.pdp import format_pdp_text, PersonalDevelopmentPlan, DevelopmentGoal
        
        mock_goal = DevelopmentGoal(
            metric="methodology",
            metric_name="Методология",
            current_score=4.5,
            target_score=7.0,
            gap=2.5,  # target - current
            priority="high",
            priority_reason="Критично",
            timeline="30 дней",
            actions=[],
            resources=[],
        )
        
        mock_pdp = PersonalDevelopmentPlan(
            role="designer",
            role_name="Дизайнер",
            experience="middle",
            experience_name="1-3 года",
            total_score=56,
            main_focus="Системное мышление",
            overall_assessment="",
            primary_goals=[mock_goal],
            plan_30_days=["Изучить материалы"],
            plan_60_days=["НЕ ДОЛЖНО БЫТЬ"],
            plan_90_days=["НЕ ДОЛЖНО БЫТЬ"],
            success_metrics=["Повышение балла"],
            learning_style_tips=[],
            motivation_message="",
        )
        
        result = format_pdp_text(mock_pdp)
        
        checks = [
            ("30 ДНЕЙ" in result, "'30 ДНЕЙ' в заголовке"),
            ("60 дней" not in result.lower() or "НЕ ДОЛЖНО" not in result, "нет 60 дней"),
            ("90 дней" not in result.lower() or "НЕ ДОЛЖНО" not in result, "нет 90 дней"),
            ("🔥" not in result, "нет эмодзи 🔥"),
            ("ПРИОРИТЕТНЫЕ ЗОНЫ" in result, "секция приоритетов"),
        ]
        
        passed = 0
        for check, desc in checks:
            if check:
                passed += 1
                print(f"  ✅ {desc}")
            else:
                print(f"  ❌ {desc}")
        
        print(f"\n  Пройдено {passed}/{len(checks)}")
        return passed == len(checks)
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_share_card_levels():
    """Тест новых уровней в share card."""
    print("\n" + "="*60)
    print("🧪 Тест: Share Card Levels")
    print("="*60)
    
    try:
        from src.utils.share_card import get_level
        
        test_cases = [
            (10, "Junior"), (24, "Junior"),
            (25, "Junior+"), (39, "Junior+"),
            (40, "Middle"), (59, "Middle"),
            (60, "Middle+"), (74, "Middle+"),
            (75, "Senior"), (84, "Senior"),
            (85, "Lead"), (100, "Lead"),
        ]
        
        passed = 0
        for score, expected in test_cases:
            level, _ = get_level(score)
            if level == expected:
                passed += 1
                print(f"  ✅ {score} → {level}")
            else:
                print(f"  ❌ {score} → {level} (ожидалось {expected})")
        
        print(f"\n  Пройдено {passed}/{len(test_cases)}")
        return passed == len(test_cases)
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


def test_russian_labels():
    """Тест русских названий категорий."""
    print("\n" + "="*60)
    print("🧪 Тест: Russian Category Labels")
    print("="*60)
    
    try:
        import inspect
        from src.utils import share_card
        source = inspect.getsource(share_card.generate_share_card)
        
        checks = [
            ("Навыки" in source, "'Навыки' в share_card"),
            ("Коммуникация" in source, "'Коммуникация'"),
            ("Мышление" in source, "'Мышление'"),
            ("Майндсет" in source, "'Майндсет'"),
        ]
        
        passed = 0
        for check, desc in checks:
            if check:
                passed += 1
                print(f"  ✅ {desc}")
            else:
                print(f"  ❌ {desc}")
        
        print(f"\n  Пройдено {passed}/{len(checks)}")
        return passed == len(checks)
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


def test_ai_timeout():
    """Тест настроек timeout для AI."""
    print("\n" + "="*60)
    print("🧪 Тест: AI Timeout Settings")
    print("="*60)
    
    try:
        import inspect
        from src.ai import client
        source = inspect.getsource(client.get_ai_client)
        
        checks = [
            ("60.0" in source, "timeout = 60 сек"),
            ("15.0" in source, "connect = 15 сек"),
        ]
        
        passed = 0
        for check, desc in checks:
            if check:
                passed += 1
                print(f"  ✅ {desc}")
            else:
                print(f"  ❌ {desc}")
        
        print(f"\n  Пройдено {passed}/{len(checks)}")
        return passed == len(checks)
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


def main():
    """Запуск всех тестов."""
    print("\n" + "🚀 ЗАПУСК ТЕСТОВ АНАЛИТИКИ")
    print("="*60)
    
    results = []
    
    # Основные компоненты
    results.append(("CompetencyProfile", test_competency_profile()))
    results.append(("PDP", test_pdp()))
    results.append(("JSON Parser", test_json_parser()))
    results.append(("_detect_style", test_detect_style()))
    results.append(("Formatters", test_formatters()))
    results.append(("ShareCard", test_share_card()))
    results.append(("PDF Generator", test_pdf_generator()))
    
    # Дополнительные компоненты
    results.append(("Keyboards", test_keyboards()))
    results.append(("Prompts", test_prompts()))
    results.append(("Serialization", test_dataclass_serialization()))
    results.append(("Error Recovery", test_error_recovery()))
    results.append(("Accessibility", test_accessibility()))
    results.append(("Progress Report", test_progress_report()))
    
    # НОВЫЕ ТЕСТЫ (Phase 4)
    results.append(("Answer Validation", test_answer_validation()))
    results.append(("PDP 30 Days", test_pdp_30_days_format()))
    results.append(("Share Card Levels", test_share_card_levels()))
    results.append(("Russian Labels", test_russian_labels()))
    results.append(("AI Timeout", test_ai_timeout()))
    
    # Итоги
    print("\n" + "="*60)
    print("📊 ИТОГИ")
    print("="*60)
    
    passed = sum(1 for _, ok in results if ok)
    total = len(results)
    
    for name, ok in results:
        status = "✅" if ok else "❌"
        print(f"  {status} {name}")
    
    print(f"\n  Пройдено: {passed}/{total}")
    
    if passed == total:
        print("\n🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        return 0
    else:
        print("\n⚠️ ЕСТЬ ОШИБКИ!")
        return 1


if __name__ == "__main__":
    sys.exit(main())

